"""
Token-Based Authentication
 if session cookies continue to fail (especially with Tauri/Electron apps)
"""

import json
import os
import random
import string
import uuid
import time
import secrets
from pathlib import Path
from datetime import datetime, timedelta
from flask_cors import CORS
os.environ['TORCH_WEIGHTS_ONLY_SAFE_LOAD'] = 'False'

from flask import Flask, request, jsonify, redirect, url_for
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
from functools import wraps

from model import FlexibleNutDetectionService

app = Flask(__name__)

# Simple CORS - allow everything for local development [Important stuff -----  not  for production ]
CORS(app, resources={r"/*": {"origins": "*"}})

app.config['SECRET_KEY'] = 'flask-insecure-change-in-production'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///marelli_flask.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['UPLOAD_FOLDER'] = 'uploads'
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024

# Create directories
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
os.makedirs(os.path.join(app.config['UPLOAD_FOLDER'], 'OK'), exist_ok=True)
os.makedirs(os.path.join(app.config['UPLOAD_FOLDER'], 'NG'), exist_ok=True)

db = SQLAlchemy(app)

# Global ML service instance
ml_service = None

# In-memory token storage (use Redis in production for better caching stuff iykyk )
active_tokens = {}

def load_ml_service():
    """Load the ML detection service from model.py"""
    global ml_service
    
    try:
        ml_service = FlexibleNutDetectionService()
        print(f"FlexibleNutDetectionService loaded successfully")
        return True
        
    except Exception as e:
        raise RuntimeError(f"Failed to load ML Detection Service: {str(e)}")

# Database Models
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(120), nullable=False)
    role = db.Column(db.String(20), default='user')
    employee_id = db.Column(db.String(50))
    department = db.Column(db.String(100))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    inspections = db.relationship('InspectionRecord', backref='user', lazy=True)

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

class InspectionRecord(db.Model):
    id = db.Column(db.String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    image_id = db.Column(db.String(100), nullable=False, index=True)
    capture_datetime = db.Column(db.DateTime, default=datetime.utcnow)
    original_image_path = db.Column(db.String(500))
    annotated_image_path = db.Column(db.String(500))
    nuts_present = db.Column(db.Integer, default=0)
    nuts_absent = db.Column(db.Integer, default=0)
    total_nuts_expected = db.Column(db.Integer, default=4)
    test_status = db.Column(db.String(2), default='OK')
    processing_time = db.Column(db.Float, default=0.0)
    confidence_scores = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

def generate_token():
    """Generate a secure random token"""
    return secrets.token_urlsafe(32)

def token_required(f):
    """Decorator to require valid token for endpoints"""
    @wraps(f)
    def decorated(*args, **kwargs):
        token = request.headers.get('Authorization')
        
        if not token:
            token = request.args.get('token')
        
        if token and token.startswith('Bearer '):
            token = token[7:]
        
        print(f"\n=== TOKEN CHECK ===")
        print(f"Token received: {token[:20] if token else 'None'}...")
        print(f"Active tokens count: {len(active_tokens)}")
        
        if not token or token not in active_tokens:
            print("❌ Token invalid or missing")
            return jsonify({'success': False, 'error': 'Authentication required'}), 401
        
        # Check token expiry
        token_data = active_tokens[token]
        if datetime.utcnow() > token_data['expires']:
            print("❌ Token expired")
            del active_tokens[token]
            return jsonify({'success': False, 'error': 'Token expired'}), 401
        
        # Get user
        user = User.query.get(token_data['user_id'])
        if not user:
            print("❌ User not found")
            return jsonify({'success': False, 'error': 'User not found'}), 401
        
        print(f"✅ Token valid for user: {user.username}")
        
        # Pass user to the endpoint
        return f(user, *args, **kwargs)
    
    return decorated

def generate_random_id(length=8):
    """Generate random alphanumeric ID"""
    return ''.join(random.choices(string.ascii_uppercase + string.digits, k=length))

def allowed_file(filename):
    """Return True when the filename has an allowed extension."""
    allowed_extensions = {'png', 'jpg', 'jpeg', 'gif', 'bmp'}
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in allowed_extensions

def process_image_with_ml_service(image_path, image_id, user_id=None):
    """Process image using the FlexibleNutDetectionService from model.py"""
    global ml_service
    
    if ml_service is None:
        raise RuntimeError("ML Detection Service not loaded")
    
    try:
        result = ml_service.process_image_with_id(
            image_path=image_path,
            image_id=image_id,
            user_id=user_id
        )
        
        if not result['success']:
            raise RuntimeError(result.get('error', 'ML processing failed'))
        
        decision = result['decision']
        
        # Calculate missing count correctly
        total_expected = 4
        nuts_present = decision['present_count']
        nuts_absent = total_expected - nuts_present  # Calculate from expected vs present
        
        # Determine test status from decision action
        test_status = 'OK' if decision.get('action') == 'APPROVED' else 'NG'
        
        print(f"\n=== DECISION MAPPING ===")
        print(f"ML Decision Status: {decision.get('status')}")
        print(f"ML Decision Action: {decision.get('action')}")
        print(f"Nuts Present: {nuts_present}")
        print(f"Nuts Missing (calculated): {nuts_absent}")
        print(f"Flask Test Status: {test_status}")
        print(f"Box Color: {decision.get('box_color')}")
        
        flask_result = {
            'nuts_present': nuts_present,
            'nuts_absent': nuts_absent,  # Use calculated value
            'total_expected': total_expected,
            'test_status': test_status,
            'processing_time': result.get('processing_time', 0.0),
            'confidence_scores': [det['confidence'] for det in result.get('detections', [])],
            'annotated_image_path': result.get('annotated_image_path', ''),
            'decision_details': decision
        }
        
        print(f"ML Service Results: {flask_result}")
        return flask_result
        
    except Exception as e:
        raise RuntimeError(f"ML service processing failed: {str(e)}")

# Routes
@app.route('/')
def index():
    """Root endpoint"""
    return jsonify({
        'message': 'Marelli QC API',
        'version': '2.0-token-based',
        'auth_type': 'Bearer Token'
    })

@app.route('/login', methods=['POST'])
def login():
    """Login endpoint - returns token instead of session cookie"""
    data = request.get_json() if request.is_json else request.form
    username = data.get('username')
    password = data.get('password')

    print(f"\n=== LOGIN ATTEMPT (Token-Based) ===")
    print(f"Username: {username}")

    if not username or not password:
        return jsonify({'success': False, 'message': 'Username and password required'}), 400

    user = User.query.filter_by(username=username).first()

    if user and user.check_password(password):
        # Generate token
        token = generate_token()
        expires = datetime.utcnow() + timedelta(hours=24)
        
        # Store token
        active_tokens[token] = {
            'user_id': user.id,
            'expires': expires,
            'created': datetime.utcnow()
        }
        
        print(f"✅ Login successful for user: {username}")
        print(f"✅ Token generated: {token[:20]}...")
        
        return jsonify({
            'success': True,
            'message': 'Login successful',
            'token': token,
            'expires': expires.isoformat(),
            'user': {
                'id': user.id,
                'username': user.username,
                'role': user.role
            },
            'model_status': 'FlexibleNutDetectionService loaded and ready' if ml_service else 'ML Service NOT loaded'
        })
    else:
        print(f"❌ Login failed for user: {username}")
        return jsonify({'success': False, 'message': 'Invalid credentials'}), 401

@app.route('/logout', methods=['POST'])
@token_required
def logout(user):
    """Logout endpoint"""
    token = request.headers.get('Authorization')
    if token and token.startswith('Bearer '):
        token = token[7:]
    
    if token in active_tokens:
        del active_tokens[token]
    
    return jsonify({'success': True, 'message': 'Logged out successfully'})

@app.route('/api/check-auth', methods=['GET'])
@token_required
def check_auth(user):
    """Check if token is valid"""
    return jsonify({
        'authenticated': True,
        'user': {
            'id': user.id,
            'username': user.username,
            'role': user.role
        }
    })

@app.route('/dashboard')
@token_required
def dashboard(user):
    """User dashboard"""
    service_stats = {}
    if ml_service and hasattr(ml_service, 'stats'):
        service_stats = ml_service.stats
        
    return jsonify({
        'user': {
            'id': user.id,
            'username': user.username,
            'email': user.email,
            'role': user.role,
            'department': user.department
        },
        'service_stats': service_stats,
        'ml_service_status': 'loaded' if ml_service else 'not_loaded'
    })

@app.route('/api/generate-id', methods=['GET'])
@token_required
def generate_id_endpoint(user):
    """Generate random image ID for tracking"""
    try:
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        random_id = generate_random_id(8)
        image_id = f"IMG_{random_id}_{timestamp}"
        
        return jsonify({
            'success': True,
            'image_id': image_id,
            'generated_at': datetime.utcnow().isoformat(),
            'user_id': user.id,
            'message': 'Image ID generated successfully'
        })
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/process-image', methods=['POST'])
@token_required
def process_image_endpoint(user):
    """Process uploaded image with ML service and return results"""
    try:
        print(f"\n=== PROCESS IMAGE (Token-Based) ===")
        print(f"Process image called by user: {user.username}")
        
        if 'image' not in request.files:
            return jsonify({'success': False, 'message': 'No image file provided'}), 400
        
        file = request.files['image']
        image_id = request.form.get('image_id')
        
        if file.filename == '':
            return jsonify({'success': False, 'message': 'No file selected'}), 400
        
        if not image_id:
            image_id = f"IMG_{generate_random_id(8)}_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        
        if file and allowed_file(file.filename):
            filename = secure_filename(file.filename)
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            filename = f"{image_id}_{timestamp}_{filename}"
            
            temp_filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            file.save(temp_filepath)
            
            # Process with ML service
            model_results = process_image_with_ml_service(temp_filepath, image_id, user.id)
            
            # Move to appropriate folder based on result
            status_folder = 'OK' if model_results['test_status'] == 'OK' else 'NG'
            final_filepath = os.path.join(app.config['UPLOAD_FOLDER'], status_folder, filename)
            
            os.rename(temp_filepath, final_filepath)
            
            # Save to database
            inspection = InspectionRecord(
                user_id=user.id,
                image_id=image_id,
                original_image_path=final_filepath,
                annotated_image_path=model_results.get('annotated_image_path', ''),
                nuts_present=model_results['nuts_present'],
                nuts_absent=model_results['nuts_absent'],
                total_nuts_expected=model_results['total_expected'],
                test_status=model_results['test_status'],
                processing_time=model_results['processing_time'],
                confidence_scores=json.dumps(model_results['confidence_scores'])
            )
            
            db.session.add(inspection)
            db.session.commit()
            
            return jsonify({
                'success': True,
                'message': 'Image processed successfully',
                'results': {
                    'inspection_id': inspection.id,
                    'image_id': image_id,
                    'test_status': model_results['test_status'],
                    'nuts_present': model_results['nuts_present'],
                    'nuts_absent': model_results['nuts_absent'],
                    'total_expected': model_results['total_expected'],
                    'confidence_scores': model_results['confidence_scores'],
                    'processing_time': model_results['processing_time'],
                    'image_path': final_filepath,
                    'annotated_image_path': model_results.get('annotated_image_path', ''),
                    'decision_details': model_results.get('decision_details', {}),
                    'processed_at': datetime.utcnow().isoformat()
                }
            })
        else:
            return jsonify({'success': False, 'message': 'Invalid file type'}), 400
            
    except Exception as e:
        print(f"Error processing image: {str(e)}")
        import traceback
        traceback.print_exc()
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/inspections', methods=['GET'])
@token_required
def get_inspections(user):
    """Get all inspections for current user"""
    try:
        inspections = InspectionRecord.query.filter_by(user_id=user.id).order_by(InspectionRecord.created_at.desc()).all()
        
        results = []
        for inspection in inspections:
            results.append({
                'id': inspection.id,
                'image_id': inspection.image_id,
                'capture_datetime': inspection.capture_datetime.isoformat(),
                'test_status': inspection.test_status,
                'nuts_present': inspection.nuts_present,
                'nuts_absent': inspection.nuts_absent,
                'processing_time': inspection.processing_time,
                'created_at': inspection.created_at.isoformat()
            })
        
        return jsonify({
            'success': True,
            'inspections': results,
            'total_count': len(results)
        })
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

from flask import send_from_directory

@app.route('/api/get-image/<path:filename>')
def get_image_public(filename):
    """Serve processed images - supports both token in header and query param"""
    try:
        # Check for token in Authorization header
        token = request.headers.get('Authorization')
        if token and token.startswith('Bearer '):
            token = token[7:]
        
        # If no header token, check query param
        if not token:
            token = request.args.get('token')
        
        # Validate token
        if not token or token not in active_tokens:
            return jsonify({'error': 'Authentication required'}), 401
        
        # Check token expiry
        token_data = active_tokens[token]
        if datetime.utcnow() > token_data['expires']:
            del active_tokens[token]
            return jsonify({'error': 'Token expired'}), 401
        
        # Handle both Windows and Unix paths
        import os
        filename = filename.replace('\\', os.sep).replace('/', os.sep)
        
        # Determine directory
        if 'result' in filename.lower():
            directory = os.path.join('media', 'inspections', 'results')
            filename = os.path.basename(filename)
        else:
            directory = 'uploads'
            filename = os.path.basename(filename)
        
        print(f"Serving image: {filename} from {directory}")
        return send_from_directory(directory, filename)
    except Exception as e:
        print(f"Error serving image: {e}")
        return jsonify({'error': str(e)}), 404
    
@app.route('/api/model-status', methods=['GET'])
@token_required
def model_status(user):
    """Check ML service status"""
    status_info = {
        'service_loaded': ml_service is not None,
        'service_type': 'FlexibleNutDetectionService from model.py',
        'model_exists': os.path.exists('models/industrial_nut_detection.pt')
    }
    
    if ml_service:
        try:
            status_info['service_healthy'] = True
            status_info['statistics'] = ml_service.stats
            if hasattr(ml_service, 'config'):
                status_info['configuration'] = ml_service.config
        except Exception as e:
            status_info['service_error'] = str(e)
    
    return jsonify(status_info)

    
if __name__ == '__main__':
    with app.app_context():
        db.create_all()
        
        try:
            load_ml_service()
        except Exception as e:
            print(f"⚠️ FATAL ERROR: {str(e)}")
            print("⚠️ Application cannot start without ML Detection Service")
            exit(1)
        
        # Create default admin user if not exists
        admin_user = User.query.filter_by(username='admin').first()
        if not admin_user:
            admin_user = User(
                username='admin',
                email='admin@marelli.com',
                role='admin',
                employee_id='ADMIN001',
                department='IT'
            )
            admin_user.set_password('admin123')
            db.session.add(admin_user)
            db.session.commit()
            print("✅ Created default admin user: admin/admin123")
        
        print("✅ Flask app starting with TOKEN-BASED authentication")
        print("📋 Available endpoints:")
        print("  - POST /login - Login with credentials (returns token)")
        print("  - POST /logout - Logout (requires Bearer token)")
        print("  - GET /dashboard - User dashboard (requires Bearer token)") 
        print("  - GET /api/generate-id - Generate image ID (requires Bearer token)")
        print("  - POST /api/process-image - Process image with ML (requires Bearer token)")
        print("  - GET /api/inspections - View inspection history (requires Bearer token)")
        print("  - GET /api/model-status - Check service status (requires Bearer token)")
        print("  - GET /api/check-auth - Check authentication status (requires Bearer token)")
        print("\n🔑 Use 'Authorization: Bearer <token>' header for authenticated requests")
        
        app.run(debug=True, host='0.0.0.0', port=5000)