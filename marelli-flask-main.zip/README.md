# Marelli Industrial Nut Detection – Flask Mini Server


## Quick start

1. **Create and activate a virtual environment** 
2. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
3. Run the development server:
   ```bash
   python app.py
   ```
   The API listens on `http://localhost:5000` by default and binds to `0.0.0.0` for LAN testing.

### Default credentials
- Username: `admin`
- Password: `admin123`
The account is created automatically if it does not exist when the app boots.

## Working endpoints + Model Integration

| Capability | Endpoint | Method | Notes |
| --- | --- | --- | --- |
| Random ID generation | `/api/generate-id` | GET | Returns a unique ID tied to the signed-in user. |
| Update/Delete inspections | `/api/inspections` | GET | Lists the caller’s inspection history. |
|  | `/api/inspections/<inspection_id>` | PUT / DELETE | Updates counts or removes an inspection. |
| ML model response | `/api/process-image` | POST | Accepts an image upload, runs mock inference, persists the result. |



