import os
import sys

# CRITICAL: Set this BEFORE any other imports
os.environ['TORCH_WEIGHTS_ONLY_SAFE_LOAD'] = 'False'
os.environ['PYTORCH_ENABLE_MPS_FALLBACK'] = '1'

print("Environment variables set successfully")
print(f"TORCH_WEIGHTS_ONLY_SAFE_LOAD = {os.environ.get('TORCH_WEIGHTS_ONLY_SAFE_LOAD')}")

# Now import and run the app
if __name__ == '__main__':
    import app